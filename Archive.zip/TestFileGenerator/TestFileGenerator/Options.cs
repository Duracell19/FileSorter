using CommandLine;

namespace TestFileGenerator;

public class Options
{
    [Option('l', "file-size", Required = false, HelpText = "Set size of the generated file (GB). Default size is 1 GB. Maximum value is 100 GB.")]
    public long SizeOfFileGb { get; set; } = 1;

    [Option('s', "max-string-length", Required = false, HelpText = "Set maximum count of symbols for generated strings. Default value is 50 symbols. Maximum value is 100 symbols.")]
    public int StringLength { get; set; } = 50;

    [Option('n', "max-num-length", Required = false, HelpText = "Set maximum count of symbols for generated number. Default value is 5 symbols. Maximum value is 7 symbols.")]
    public int NumberLength { get; set; } = 5;

    [Option('r', "repeatance", Required = false, HelpText = "Set repeatance percentage. Default value is 60%. Maximum value is 100%.")]
    public double RepeatancePercentage { get; set; } = 60;
}