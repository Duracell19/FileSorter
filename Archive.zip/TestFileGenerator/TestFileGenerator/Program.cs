﻿using CommandLine;
using TestFileGenerator;

Parser.Default.ParseArguments<Options>(args)
    .WithParsed(HandleArguments)
    .WithNotParsed(HandleError);

return;

static void HandleArguments(Options options)
{
    if (!IsOptionsValid(options))
    {
        return;
    }

    RunFileGenerator(options);
}

static bool IsOptionsValid(Options options)
{
    const int sizeBufferGb = 100;
    const int maxNumLength = 7;
    const int maxStringLength = 100;

    if (options.SizeOfFileGb is > sizeBufferGb or < 1)
    {
        Console.WriteLine($"Wrong value for 'file-size': {options.SizeOfFileGb}");
        return false;
    }
    if (options.StringLength is >= maxStringLength or < 1)
    {
        Console.WriteLine($"Wrong value for 'string-length': {options.StringLength}");
        return false;
    }
    if (options.NumberLength is >= maxNumLength or < 1)
    {
        Console.WriteLine($"Wrong value for 'num-length': {options.NumberLength}");
        return false;
    }
    if (options.RepeatancePercentage is > 100 or < 0)
    {
        Console.WriteLine($"Wrong value for 'repeatance': {options.RepeatancePercentage}");
        return false;
    }

    return true;
}

static void HandleError(IEnumerable<Error> errors)
{
    Console.WriteLine("Wrong arguments were set.");
}

static void RunFileGenerator(Options options)
{
    var fileGenerator = new FileGenerator(options);
    fileGenerator.Run();
}