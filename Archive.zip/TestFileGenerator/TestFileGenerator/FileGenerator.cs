using System.Text;

namespace TestFileGenerator;

public class FileGenerator(Options options)
{
    private const string FileName = "unsorted_test_data.txt";
    private const string Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ";
    private static readonly int[] Numbers = [0, 1, 2, 4, 5, 6, 7, 8, 9];

    public void Run()
    {
        Console.WriteLine("Generation has been started...");

        var random = new Random();

        var targetSizeBytes = options.SizeOfFileGb * 1024 * 1024 * 1024;
        using (var writer = new StreamWriter(FileName))
        {
            var currentSize = 0L;
            var previousStrings = new Dictionary<int, string>();
            var previousStringsIndex = 0;
            var repeatChance = options.RepeatancePercentage / 100;

            while (currentSize <= targetSizeBytes)
            {
                var numberLength = random.Next(1, options.NumberLength);
                var stringLength = random.Next(1, options.StringLength + 1);
                var sb = new StringBuilder(numberLength + stringLength + 3); // 3 => Memory for ',', ' ', '\n' symbols.

                GenerateRandomNumber(numberLength, sb, random);

                if (random.NextDouble() < repeatChance && previousStrings.Count > 0)
                {
                    sb.Append(GetRepeatingString(previousStrings, random));
                }
                else
                {
                    var generatedString = GenerateRandomString(stringLength, random);
                    previousStrings[previousStringsIndex] = generatedString;
                    previousStringsIndex++;
                    sb.Append(generatedString);
                }

                var randomString = sb.ToString();
                writer.WriteLine(randomString);
                currentSize += Encoding.UTF8.GetByteCount(randomString + Environment.NewLine);
            }
        }

        Console.WriteLine($"Generation has been finished. The file {FileName} was created.");
    }

    private static void GenerateRandomNumber(int numberLength, StringBuilder sb, Random random)
    {
        for (var i = 0; i < numberLength; i++)
        {
            var substr = Numbers[random.Next(Numbers.Length)];
            sb.Append(substr == 0 && i == 0 && numberLength > 1 ? 1 : substr);
        }

        sb.Append(". ");
    }

    private static string GenerateRandomString(int stringLength, Random random)
    {
        var sb = new StringBuilder(stringLength);
        for (var i = 0; i < stringLength; i++)
        {
            var substr = Chars[random.Next(Chars.Length)];
            sb.Append(substr == ' ' && i == 0 ? 'a' : substr);
        }

        return sb.ToString();
    }

    private static string GetRepeatingString(Dictionary<int, string> previousStrings, Random random)
    {
        var index = random.Next(previousStrings.Count);
        return previousStrings[index];
    }
}