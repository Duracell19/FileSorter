using CommandLine;

namespace SorterUtility;

public class Options
{
    [Option('p', "file-path", Required = false, HelpText = "Set file path. Default value is 'unsorted_test_data.txt'")]
    public string FilePath { get; set; } = "unsorted_test_data.txt";
}