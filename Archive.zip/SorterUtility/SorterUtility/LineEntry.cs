namespace SorterUtility;

public class LineEntry(string line, StreamReader reader) : IComparable<LineEntry>
{
    public string Line { get; } = line;
    public StreamReader Reader { get; } = reader;
    private (string, long) LineParts { get; } = ParseLine(line);

    private static (string, long) ParseLine(string line)
    {
        var parts = line.Split('.', StringSplitOptions.TrimEntries);
        return (parts[1], long.Parse(parts[0]));
    }

    public int CompareTo(LineEntry? lineEntry)
    {
        var result = LineParts.Item1.CompareTo(lineEntry.LineParts.Item1);
        if (result == 0)
        {
            result = LineParts.Item2.CompareTo(lineEntry.LineParts.Item2);
        }

        return result;
    }
}