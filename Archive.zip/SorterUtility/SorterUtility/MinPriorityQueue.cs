namespace SorterUtility;

public class MinPriorityQueue
{
    private readonly List<LineEntry> _elements = [];

    public bool IsEmpty() => _elements.Count == 0;

    public void Insert(LineEntry item)
    {
        _elements.Add(item);
        var i = _elements.Count - 1;
        while (i > 0)
        {
            var parentIndex = (i - 1) / 2;
            if (_elements[parentIndex].CompareTo(item) <= 0)
            {
                break;
            }
            Swap(i, parentIndex);
            i = parentIndex;
        }
    }

    public LineEntry Extract()
    {
        var result = _elements[0];
        _elements[0] = _elements.Last();
        _elements.RemoveAt(_elements.Count - 1);
        CompareHeap(0);
        return result;
    }

    private void CompareHeap(int index)
    {
        while (true)
        {
            var left = 2 * index + 1;
            var right = 2 * index + 2;
            var smallest = index;
            if (left < _elements.Count && _elements[left].CompareTo(_elements[smallest]) < 0)
            {
                smallest = left;
            }

            if (right < _elements.Count && _elements[right].CompareTo(_elements[smallest]) < 0)
            {
                smallest = right;
            }

            if (smallest != index)
            {
                Swap(index, smallest);
                index = smallest;
                continue;
            }

            break;
        }
    }

    private void Swap(int i, int j)
    {
        (_elements[i], _elements[j]) = (_elements[j], _elements[i]);
    }
}