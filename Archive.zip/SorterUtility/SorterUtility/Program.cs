﻿using CommandLine;
using SorterUtility;

Parser.Default.ParseArguments<Options>(args)
    .WithParsed(HandleArguments)
    .WithNotParsed(HandleError);

return;

static void HandleArguments(Options options)
{
    if (!IsOptionsValid(options))
    {
        return;
    }

    RunFileGenerator(options);
}

static bool IsOptionsValid(Options options)
{
    if (!string.IsNullOrEmpty(options.FilePath)) return true;

    Console.WriteLine("Wrong value for 'file-path'");
    return false;

}

static void HandleError(IEnumerable<Error> errors)
{
    Console.WriteLine("Wrong arguments were set.");
}

static void RunFileGenerator(Options options)
{
    var fileSorter = new FileSorter(options);
    fileSorter.Run();
}