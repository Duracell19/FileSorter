namespace SorterUtility;

public class StringComparer : IComparer<(string, long)>
{
    public int Compare((string, long) x, (string, long) y)
    {
        var result = x.Item1.CompareTo(y.Item1);
        if (result == 0)
        {
            result = x.Item2.CompareTo(y.Item2);
        }

        return result;
    }
}