using System.Diagnostics;
using System.IO.MemoryMappedFiles;
using System.Text;

namespace SorterUtility;

public class FileSorter(Options options)
{
    private const string OutputFileName = "sorted_test_data.txt";
    private const string ChunkDirectory = "Chunks";
    private const char Separator = '.';
    private const int MaxLinesPerChunk = 5000000;

    public void Run()
    {
        Console.WriteLine("Sorting has been started...");

        Directory.CreateDirectory(ChunkDirectory);

        SortLargeFile(options.FilePath, OutputFileName, MaxLinesPerChunk);

        Console.WriteLine($"Sorting has been finished. The file {OutputFileName} was created.");

        Console.WriteLine("Cleaning the directory..");
        Directory.Delete(ChunkDirectory, true);
        Console.WriteLine("Directory was cleaned.");
    }

    private static void SortLargeFile(string inputFilePath, string outputFilePath, int maxLinesPerChunk)
    {
        var stopWatch = new Stopwatch();
        stopWatch.Start();

        var files = SplitFile(inputFilePath, maxLinesPerChunk);
        Console.WriteLine($@"Step 1/3. Chunks are created: {stopWatch.Elapsed:mm\:ss\.fff}");

        var chunkFiles = files.Chunk(10);
        foreach (var chunk in chunkFiles)
        {
            Parallel.ForEach(chunk, SortChunk);
        }
        Console.WriteLine($@"Step 2/3. Chunks are sorted: {stopWatch.Elapsed:mm\:ss\.fff}");

        MergeChunks(files, outputFilePath);
        Console.WriteLine($@"Step 3/3. Chunks are merged: {stopWatch.Elapsed:mm\:ss\.fff}");

        stopWatch.Stop();
    }

    private static List<string> SplitFile(string filePath, int maxLinesPerChunk)
    {
        var chunkFiles = new List<string>();

        using var reader = new StreamReader(filePath);
        var endOfFile = false;
        var chunkIndex = 0;

        while (!endOfFile)
        {
            var chunkFileName = $"{ChunkDirectory}/chunk_{chunkIndex}.txt";
            chunkFiles.Add(chunkFileName);
            using (var writer = new StreamWriter(chunkFileName))
            {
                for (var i = 0; i < maxLinesPerChunk; i++)
                {
                    if (reader.EndOfStream)
                    {
                        endOfFile = true;
                        break;
                    }

                    writer.WriteLine(reader.ReadLine());
                }
            }

            chunkIndex++;
        }

        return chunkFiles;
    }

    private static void SortChunk(string filePath)
    {
        var fileSize = new FileInfo(filePath).Length;

        using var file = MemoryMappedFile.CreateFromFile(filePath, FileMode.Open);
        using var accessor = file.CreateViewAccessor(0, fileSize);
        var buffer = new byte[fileSize];

        accessor.ReadArray(0, buffer, 0, buffer.Length);
        var content = Encoding.UTF8.GetString(buffer);
        var lines = content.Split([Environment.NewLine], StringSplitOptions.RemoveEmptyEntries)
            .AsParallel()
             .Select(str =>
             {
                 var parts = str.Split(Separator, StringSplitOptions.TrimEntries);
                 return (parts[1], long.Parse(parts[0]));
             }).ToArray();

        Array.Sort(lines, new StringComparer());
        var resultLines = lines.Select(line => $"{line.Item2}. {line.Item1}");

        File.WriteAllLines(filePath, resultLines);
        accessor.Flush();
    }

    private static void MergeChunks(List<string> chunkFiles, string outputFilePath)
    {
        var minHeap = new MinPriorityQueue();
        var readers = new List<StreamReader>();

        foreach (var reader in chunkFiles.Select(chunkFile => new StreamReader(chunkFile)))
        {
            if (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var entry = new LineEntry(line!, reader);
                minHeap.Insert(entry);
            }
            readers.Add(reader);
        }

        using (var writer = new StreamWriter(outputFilePath))
        {
            while (!minHeap.IsEmpty())
            {
                var minEntry = minHeap.Extract();
                writer.WriteLine(minEntry.Line);
                var reader = minEntry.Reader;

                if (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var newEntry = new LineEntry(line!, reader);
                    minHeap.Insert(newEntry);
                }
                else
                {
                    reader.Dispose();
                }
            }
        }

        foreach (var reader in readers)
        {
            reader.Dispose();
        }
    }
}